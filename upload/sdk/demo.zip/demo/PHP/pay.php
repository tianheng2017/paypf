<?php

	/** post跳转方式发起请求
	 * @param  string $tjurl
	 * @param  array $arraystr
	 */
	function sendHttpPostForm($tjurl, $arraystr)
	{
		$str = '<form id="Form1" name="Form1" method="post" action="' . $tjurl . '" >';
		foreach ($arraystr as $key => $val) {
			$str .= '<input type="hidden" name="' . $key . '" value="' . $val . '">';
		}
		$str .= '</form>';
		$str .= '<script>';
		$str .= 'document.Form1.submit();';
		$str .= '</script>';
		exit($str);

	}

	/**
	 * Curl方式发起请求
	 * 获取json
	 */
	function sendHttpPostCurl($url, $data = null, $header = null, $referer = null)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_URL, $url);

		if ($header) {
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		}
		if ($referer) {
			curl_setopt($ch, CURLOPT_REFERER, $referer);
		}
		if ($data) {
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		} else {
			curl_setopt($ch, CURLOPT_POST, false);
		}
		if (stripos($url, 'https://') !== false) {
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);   // 跳过证书检查
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);   // 从证书中检查SSL加密算法是否存在
		}

		//  curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));   //避免data数据过长问题
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$res = curl_exec($ch);

		if ($error = curl_error($ch)) {
			echo '=====info=====' . "\r\n";
			print_r(curl_getinfo($ch));
			echo '=====error=====' . "\r\n";
			print_r(curl_error($ch));
			echo '=====$response=====' . "\r\n";
			print_r($res);
			die($error);
		}
		curl_close($ch);
		return $res;
	}
	//取得IP
	function getcip(){
		if(getenv('HTTP_CLIENT_IP')&&strcasecmp(getenv('HTTP_CLIENT_IP'),'unknown'))
		{
			$ip=getenv('HTTP_CLIENT_IP');
		}
		elseif(getenv('HTTP_X_FORWARDED_FOR')&&strcasecmp(getenv('HTTP_X_FORWARDED_FOR'),'unknown'))
		{
			$ip=getenv('HTTP_X_FORWARDED_FOR');
		}
		elseif(getenv('REMOTE_ADDR')&&strcasecmp(getenv('REMOTE_ADDR'),'unknown'))
		{
			$ip=getenv('REMOTE_ADDR');
		}
		elseif(isset($_SERVER['REMOTE_ADDR'])&&$_SERVER['REMOTE_ADDR']&&strcasecmp($_SERVER['REMOTE_ADDR'],'unknown'))
		{
			$ip=$_SERVER['REMOTE_ADDR'];
		}
		$ip=preg_replace("/^([\d\.]+).*/","\\1",$ip);
		return $ip;
	}
	$cip = "";$cip = getcip();
	
	
	
/**
 * ---------------------参数生成页-------------------------------
 * Author:Ali
 * Project:Ali
 
 appkey		appscrect		money		paytype		notify_url		return_url		orderid		orderusersign		goodsname		key

 */
	
 
	$appkey = "此处填写您的AppKey";
	$appscrect = "此处填写您的AppScrect";
	
	
	$money = $_POST["money"];
	//校验传入的表单，确保价格为正常价格（整数，1位小数，2位小数都可以），支付渠道见文档
	if(empty($money) || !preg_match("/^(([1-9][0-9]*\.[0-9][0-9]*)|([0]\.[0-9][0-9]*)|([1-9][0-9]*)|([0]{1}))$/", $money) || $money<=0){
		//echo "金额填写有误！";exit();
	}
	$money = sprintf("%.2f",substr(sprintf("%.3f", $money), 0, -1));
	
	

	
    $paytype = $_POST["paytype"];	//	521：收银台
    
    
    
    $notify_url = 'http://www.***.cn/paynotify.php';
	$return_url = 'http://www.***.cn/my.php';

	$orderusersign = "username";       //此处可传入您网站用户的用户名或UID等，强烈建议加上。可忽略。
    $goodsname = "商品名称";
    $orderid = rand(10000,99999).$appkey.time().rand(10000,99999);    //自定义订单号

    $key = md5($appkey. $appscrect . $orderid);
    //md5(appkey+ appscrect+ orderid)
	

    $param['appkey'] = $appkey;
    $param['appscrect'] = md5($appscrect);
    $param['money'] = $money;
    $param['paytype'] = $paytype;
	$param['notify_url'] = $notify_url;
    $param['return_url'] = $return_url;
    $param['orderid'] = $orderid;
	$param['cip'] = $cip;
    $param['orderusersign'] = $orderusersign;
    $param['goodsname'] = $goodsname;
    $param['key'] = $key;
    
	
	$resjson = sendHttpPostCurl("http://网关域名/pay/index.php/paydo/getjsonorderinfo",$param);
	
	$resobj = json_decode($resjson,true);
	
	if(!empty($resobj)&&!empty($resobj['code'])&&$resobj['code']==200&&!empty($resobj['data'])&&!empty($resobj['data']['oid'])&&!empty($resobj['data']['payhost'])){
		
		//跳转收银台进行支付
		
		$requrl = $resobj['data']['payhost'] . $resobj['data']['oid'].'/';
		header('Location:'.$requrl);
		
		
	}else{
		//echo "下单失败！";exit();
	}
	
	
	
	

	
?>