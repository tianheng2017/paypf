<?php
/**
 * ---------------------通知异步回调接收页-------------------------------
 * 
 * 此页就是您之前传的notify_url页的网址
 * 支付成功，会根据您之前传入的网址，回调此页URL，post回参数
 * 
 * --------------------------------------------------------------
 */

    $appkey = $_POST["appkey"];
    $appscrect = $_POST["appscrect"];
    $money = $_POST["money"];
    $orderid = $_POST["orderid"];
    $key = $_POST["key"];

    //校验传入的参数是否格式正确，略

    $myappkey = "此处填写您的AppKey";
	$myappscrect = "此处填写您的AppScrect";
    
    $iskey = md5($myappkey . $myappscrect . $orderid);

    if ($iskey != $key || $appkey != $myappkey || $appscrect != md5($myappscrect)){
        echo "ERROR";
    }else{
        //校验成功，执行自己的业务逻辑：加余额，订单付款成功。
        
		
		
		
		echo "SUCCESS";
    }

?>